package com.amdocs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoDoctorManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoDoctorManagementApplication.class, args);
	}

}
